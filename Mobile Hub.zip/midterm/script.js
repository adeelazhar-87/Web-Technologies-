// MobileHub functionality for Task 3 and the existing demo cart.
const N = 66; // Last two digits of registration number FA24-BCS-166.
const cards = Array.from(document.querySelectorAll(".product-card"));
const searchInput = document.getElementById("search");
const noResults = document.getElementById("no-results");
const productList = document.getElementById("product-list");
const sortButton = document.getElementById("sort-price");
let ascending = true;
let cart = [];

function applySearch() {
  const term = searchInput.value.trim().toLowerCase();
  let visibleCount = 0;

  cards.forEach(card => {
    const name = (card.dataset.name || "").toLowerCase();
    const matchesSearch = name.includes(term);
    card.classList.toggle("search-hidden", !matchesSearch);
    if (matchesSearch) visibleCount++;
  });

  // The CSS category radio buttons still perform the category filtering.
  // Count cards that are actually visible after both filters have applied.
  requestAnimationFrame(() => {
    const visible = cards.filter(card => getComputedStyle(card).display !== "none").length;
    noResults.style.display = visible === 0 ? "block" : "none";
  });
}

function updatePremiumLabels() {
  const threshold = N * 100;
  cards.forEach(card => {
    const button = card.querySelector("button[data-price]");
    const price = Number(button.dataset.price);
    let badge = card.querySelector(".premium");
    if (price > threshold) {
      if (!badge) {
        badge = document.createElement("span");
        badge.className = "premium";
        badge.textContent = "Premium";
        card.querySelector(".phone-image").insertAdjacentElement("afterend", badge);
      }
    } else if (badge) {
      badge.remove();
    }
  });
}

sortButton.addEventListener("click", () => {
  const sorted = [...cards].sort((a, b) => {
    const priceA = Number(a.querySelector("button[data-price]").dataset.price);
    const priceB = Number(b.querySelector("button[data-price]").dataset.price);
    return ascending ? priceA - priceB : priceB - priceA;
  });
  sorted.forEach(card => productList.appendChild(card));
  sortButton.textContent = ascending ? "Sort by price: High to Low" : "Sort by price: Low to High";
  ascending = !ascending;
  applySearch();
});

searchInput.addEventListener("input", applySearch);
document.querySelectorAll('input[name="category"]').forEach(radio => {
  radio.addEventListener("change", applySearch);
});

function updateCart() {
  const cartItems = document.getElementById("cart-items");
  const cartCount = document.getElementById("cart-count");
  const cartTotal = document.getElementById("cart-total");
  const totalQuantity = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  cartCount.textContent = totalQuantity;
  cartTotal.textContent = totalPrice.toLocaleString("en-PK");

  if (!cart.length) {
    cartItems.textContent = "Your cart is empty.";
    return;
  }
  cartItems.replaceChildren();
  cart.forEach((item, index) => {
    const row = document.createElement("div");
    row.append(`${item.name} - Rs. ${item.price.toLocaleString("en-PK")} × ${item.quantity} `);
    const remove = document.createElement("button");
    remove.type = "button";
    remove.textContent = "Remove";
    remove.addEventListener("click", () => {
      cart.splice(index, 1);
      updateCart();
    });
    row.appendChild(remove);
    cartItems.appendChild(row);
  });
}

document.querySelectorAll('button[data-price]').forEach(button => {
  button.addEventListener("click", () => {
    const name = button.dataset.name;
    const price = Number(button.dataset.price);
    const existing = cart.find(item => item.name === name);
    if (existing) existing.quantity++;
    else cart.push({name, price, quantity: 1});
    updateCart();
    alert(name + " added to cart!");
  });
});

document.getElementById("show-cart").addEventListener("click", () => {
  document.getElementById("cart").scrollIntoView({behavior: "smooth"});
});
document.getElementById("shop-now").addEventListener("click", () => {
  document.getElementById("products").scrollIntoView({behavior: "smooth"});
});
document.getElementById("checkout").addEventListener("click", () => {
  if (!cart.length) alert("Your cart is empty!");
  else alert("Order demo successful! Total: Rs. " + document.getElementById("cart-total").textContent);
});

updatePremiumLabels();
applySearch();
