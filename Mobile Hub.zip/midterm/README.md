# MobileHub Midterm Update

## Personal values
- Name: [Enter your name]
- Registration number: FA24-BCS-166
- N: 66
- BP: 600 + 66 = 666 px
- H: (66 × 7) mod 360 = 102 degrees
- K: (66 mod 3) + 3 = 3
- Category filters: All + Phones + Budget + Premium (4 radio buttons)
- Product-page sticky top offset: (66 mod 40) + 70 = 96 px

The assignment-specific values have been applied in the HTML and JavaScript files.

## Files changed
- `index.html`: Preserved the MobileHub listing and added radio-button category filters, price-sort button, and responsive styling.
- `script.js`: Added case-insensitive live search, alternating price sorting using existing card elements, Premium badges, and cart demo functionality.
- `product.html`: Added the separate product detail layout with named CSS Grid areas and a sticky details panel.
- `README.md`: Records personal values and summarizes the changes.

## Task 1 — CSS-only category filter
Added radio buttons for All and categories. CSS selectors use `:checked` and sibling selectors to show/hide product cards without JavaScript doing the category filtering. K = 3, so the page uses three categories (Phones, Budget and Premium) plus the All option.

## Task 2 — Product detail layout
Created `product.html` with named grid areas. Below 666px it stacks image, details and description. At 666px and wider, image and details sit side by side and the description spans both columns. The details panel uses `position: sticky; top: 96px`.

## Task 3 — Search, sort and Premium labels
Created `script.js`. Search matches product names without case sensitivity. Sorting reads prices from each existing card and moves cards with `appendChild`. Premium badges are created on page load for products above N × 100.

## AI tools used
- ChatGPT (review and code assistance)

## Before submission
1. Enter your name in this README.
2. Test at 375px, exactly 666px, and 1280px.
3. Take screenshots of all tasks at the required widths.
4. Make and push at least four meaningful commits as required by the statement.
5. Export the required PDF with screenshots and changed code.

## Product photos
- Added product photos for all eight listed smartphone models to the product cards and the Samsung Galaxy S24 detail page.
- Image files are referenced from their original image-hosting pages, so an internet connection is required for the photos to load. The project ZIP does not contain locally downloaded copies.
